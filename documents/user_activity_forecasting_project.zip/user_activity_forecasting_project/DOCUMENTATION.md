# User Activity Forecasting

## End-to-End Machine Learning Pipeline with Snowflake ML

---

## Executive Summary

This project implements a production-grade machine learning pipeline to predict user engagement for the next 7 days. Built entirely on Snowflake's native ML capabilities, it demonstrates enterprise-ready practices including automated retraining, model versioning, explainability, and continuous monitoring.

| Metric | Value |
|--------|-------|
| **Objective** | Predict active days (0-7) in the next week |
| **Model** | XGBoost Regressor |
| **Test MAE** | ~1.2 days |
| **Features** | 65 engineered features from 11 Feature Views |
| **Retraining** | Weekly (Sundays) |

### Model Development Summary

The final model configuration was selected through systematic experimentation:

| Experiment | Variations Tested | Outcome |
|------------|-------------------|---------|
| **Training Lookback** | 7, 30, 60, 90, 120 days of history | 30 days selected (optimal signal-to-noise ratio) |
| **Feature Engineering** | 100+ raw features → 65 curated | Removed low-variance and highly correlated features via SHAP analysis |
| **Model Comparison** | 7 algorithms (Linear, Ridge, Lasso, RF, GB, XGBoost, LightGBM) | XGBoost selected (best RMSE/MAE balance) |
| **Hyperparameter Tuning** | RandomizedSearch, Optuna (Bayesian) | Optuna-tuned parameters in production |
| **Train/Test Strategy** | Random vs Temporal split | Temporal split (prevents data leakage in time-series) |

See the `notebooks/` folder for detailed experiment notebooks.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Project Structure](#project-structure)
3. [Configuration](#configuration)
4. [Feature Store](#feature-store)
5. [Training Pipeline](#training-pipeline)
6. [Inference Pipeline](#inference-pipeline)
7. [Model Monitoring](#model-monitoring)
8. [Deployment](#deployment)
9. [Notebooks](#notebooks)
10. [Local Development](#local-development)

---

## Architecture Overview

### Pipeline Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              DATA LAYER                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│  Raw Data Tables (DATA_SCIENCE schema)                                       │
│  ├── metrics_daily_userlevel_app_time_sessions                               │
│  ├── user_profiles                                                           │
│  └── 10+ source tables                                                       │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            FEATURE STORE                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│  11 Feature Views with Point-in-Time Correctness                             │
│  ├── user_features_sessions (time in app, tenure, active days)               │
│  ├── user_features_messages (SMS, MMS by type)                               │
│  ├── user_features_calls (inbound, outbound, quality)                        │
│  └── ... (ads, ratings, data usage, etc.)                                    │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                    ┌─────────────────┴─────────────────┐
                    ▼                                   ▼
┌──────────────────────────────┐       ┌──────────────────────────────┐
│       TRAINING PIPELINE       │       │      INFERENCE PIPELINE       │
├──────────────────────────────┤       ├──────────────────────────────┤
│  1. Generate training set     │       │  1. Generate inference set    │
│  2. Temporal train/test split │       │  2. Load default model        │
│  3. Train XGBoost pipeline    │       │  3. Generate predictions      │
│  4. Log to Experiment Tracker │       │  4. Compute SHAP values       │
│  5. Promote if better (>1%)   │       │  5. Save to PREDICTIONS table │
└──────────────────────────────┘       │  6. Create monitor if needed  │
              │                         └──────────────────────────────┘
              ▼                                        │
┌──────────────────────────────┐                       ▼
│       MODEL REGISTRY          │       ┌──────────────────────────────┐
├──────────────────────────────┤       │         OUTPUT TABLES         │
│  Versioned model storage      │       ├──────────────────────────────┤
│  Default version management   │       │  PREDICTIONS (narrow format)  │
│  Model lineage tracking       │       │  PREDICTIONS_SHAP (long fmt)  │
└──────────────────────────────┘       └──────────────────────────────┘
                                                       │
                                                       ▼
                                       ┌──────────────────────────────┐
                                       │       MODEL MONITOR           │
                                       ├──────────────────────────────┤
                                       │  Drift detection              │
                                       │  Accuracy tracking            │
                                       │  Auto-refresh on schedule     │
                                       └──────────────────────────────┘
```

### Execution Schedule

| Task | Schedule | Description |
|------|----------|-------------|
| Training | Sunday 02:00 UTC | Retrain model with latest 30 days of data |
| Inference | Daily 07:00 UTC | Generate predictions + SHAP + create monitor |
| Backfill | Daily 08:00 UTC | Populate ground truth for 7-day-old predictions |

Weekly training is sufficient for user activity patterns, reducing compute costs while maintaining model freshness.

### Snowflake Components Used

| Component | Purpose |
|-----------|---------|
| **Feature Store** | Centralized feature management with point-in-time correctness |
| **Experiment Tracking** | Log and compare model experiments |
| **Model Registry** | Version, store, and govern models |
| **Model Monitor** | Track prediction performance and detect drift |
| **Snowpark Container Services** | Run containerized Python workloads |
| **Tasks** | Schedule automated daily jobs |

---

## Project Structure

```
user_activity_forecasting_project/
│
├── .github/workflows/
│   └── deploy.yml                 # CI/CD pipeline
│
├── notebooks/
│   ├── EXPERIMENTS_MASTER.ipynb         # Complete experiment workflow
│   ├── EXPERIMENTS_BASELINE.ipynb       # Baseline model comparison
│   ├── EXPERIMENTS_WITH_OPTUNA.ipynb    # Bayesian hyperparameter tuning
│   ├── EXPERIMENTS_WITH_RANDOMIZEDSEARCH.ipynb  # RandomizedSearch tuning
│   ├── FEATURE_STORE.ipynb              # Feature engineering reference
│   └── INFERENCE.ipynb                  # Inference demonstration
│
├── src/
│   ├── common/
│   │   ├── session.py             # Snowflake connection (SPCS/local)
│   │   └── utils.py               # Config, model creation, promotion
│   │
│   ├── inference/
│   │   └── predict.py             # Inference pipeline
│   │
│   ├── monitoring/
│   │   ├── backfill_actuals.py    # Populate ground truth
│   │   └── create_monitor.py      # Create model monitor
│   │
│   └── training/
│       └── train.py               # Training pipeline
│
├── tasks/
│   └── create_tasks.sql           # Snowflake task definitions
│
├── tests/
│   ├── conftest.py                # Test fixtures
│   ├── test_config.py             # Configuration validation
│   └── test_utils.py              # Utility function tests
│
├── config.yaml                    # Application configuration
├── Dockerfile                     # Container image definition
├── requirements.txt               # Python dependencies
└── DOCUMENTATION.md               # This file
```

---

## Configuration

### Design Philosophy

Configuration is split between **environment variables** (infrastructure) and **config.yaml** (application logic):

| Type | Contains | Examples |
|------|----------|----------|
| **Environment Variables** | Infrastructure, credentials | Database, warehouse, role |
| **config.yaml** | Application logic | Model hyperparameters, feature definitions |

### Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| SNOWFLAKE_DATABASE | Target database | DEV, PROD |
| SNOWFLAKE_SCHEMA | Target schema | DATA_SCIENCE |
| SNOWFLAKE_WAREHOUSE | Compute warehouse | ANALYTICS_WH_FLEX |
| SNOWFLAKE_ROLE | Snowflake role | DATASCIENCE |
| SNOWFLAKE_ACCOUNT | Account identifier | abc12345.us-east-1 |
| SNOWFLAKE_COMPUTE_POOL | SPCS compute pool | ML_COMPUTE_POOL |

### config.yaml Structure

```yaml
# Reference date: null for production (current date), or fixed for testing
reference_date: null

# Feature Store configuration with specific features per view
feature_store:
  name: "user_activity_feature_store"
  feature_views:
    - name: "user_features_ads"
      version: "1.2"
      features:
        - "CONVERSATIONENDINTERSTITIAL"
        - "P1SMSRICHMEDIA"
        # ... specific features to retrieve
    - name: "user_features_sessions"
      version: "1.2"
      features:
        - "TIME_IN_APP_MINS"
        - "SESSION_COUNT"
        - "ACTIVE_DAYS_PREV_7"
        # ... specific features to retrieve
    # ... 11 total feature views

# ID and target columns (top-level for clarity)
id_columns:
  - "USER_ID_HEX"
  - "DATE_UTC"
target_column: "ACTIVE_DAYS_IN_WEEK"

# Model configuration
model:
  registry_name: "XGBOOST_MODEL"
  class: "xgboost.XGBRegressor"
  display_name: "XGBoost"
  hyperparameters:
    n_estimators: 300
    learning_rate: 0.03
    max_depth: 8
    subsample: 0.6
    colsample_bytree: 0.6
    random_state: 42

# Training configuration
training:
  experiment_name: "User_activity_forecasting_models"
  lookback_days: 30              # Days of history for training
  label_maturity_days: 7         # Wait for labels to mature
  prediction_horizon_days: 7     # Predict 7 days ahead
  samples_per_day: 70000         # Samples per day (HASH-based)
  test_size: 0.2                 # 20% temporal holdout
  improvement_threshold: 0.01    # 1% RMSE improvement to promote

# Inference configuration
inference:
  inference_date_offset_days: 1  # Predict for yesterday's users
  data_limit: null               # null for no limit in production

# Monitoring configuration
monitoring:
  refresh_interval: "1 day"
  aggregation_window: "1 day"
  backfill_lag_days: 7

# Source and output tables
tables:
  activity_source: "METRICS_DAILY_USERLEVEL_APP_TIME_SESSIONS"
  user_lookup: "USER_PROFILES"
  predictions: "PREDICTIONS"
  predictions_shap: "PREDICTIONS_SHAP"
```

---

## Feature Store

### Overview

The Feature Store provides centralized, versioned feature management with point-in-time correctness for training and inference.

| Property | Value |
|----------|-------|
| **Database** | DEV |
| **Schema** | USER_ACTIVITY_FEATURE_STORE (auto-created) |
| **Entity** | USER_ENTITY (user_id_hex, date_utc) |
| **Total Features** | 65 across 11 Feature Views |

### Feature Views

| Feature View | Features | Description |
|--------------|----------|-------------|
| user_features_sessions | 12 | Time in app, session count, tenure, active days |
| user_features_messages | 18 | Message counts by type (SMS, MMS, voicemail) |
| user_features_ads | 5 | Ad interaction counts |
| user_features_inbound_calls | 6 | Inbound call metrics |
| user_features_outbound_calls | 6 | Outbound call metrics |
| user_features_call_quality | 2 | MOS score, RTP setup time |
| user_features_call_rating | 4 | Call rating averages |
| user_features_data_usage | 4 | Data consumption metrics |
| user_features_drawer_event | 5 | App navigation events |
| user_features_nps_rating | 2 | NPS survey responses |
| user_features_redial | 1 | Redial behavior |

### Feature Slicing

Production code retrieves only the features defined in config, not all features from each view:

```python
# In utils.py
def get_feature_views(fs, cfg):
    return [
        fs.get_feature_view(name=fv["name"], version=fv["version"])
          .slice(fv["features"])  # Only retrieve specified features
        for fv in cfg["feature_store"]["feature_views"]
        if fv.get("features")
    ]
```

This ensures:
- Consistent features between training and inference
- Single source of truth in config.yaml
- Efficient data retrieval

---

## Training Pipeline

### File: `src/training/train.py`

### Execution Flow

1. Load configuration from `config.yaml`
2. Connect to Snowflake and Feature Store
3. Build training query with label computation
4. Generate training set via Feature Store
5. **Temporal split**: 80% oldest days for training, 20% newest for testing
6. Train pipeline (StandardScaler + XGBoost)
7. Evaluate on test set (RMSE, MAE)
8. Log to Experiment Tracker
9. Promote to default if RMSE improves by >1%

### Training Query

The query correctly computes labels using a window function, then filters:

```sql
WITH daily AS (
    -- Aggregate daily activity
    SELECT username, date_utc, SUM(time_in_app_mins_per_day) AS mins
    FROM METRICS_DAILY_USERLEVEL_APP_TIME_SESSIONS
    WHERE date_utc >= '{min_date}'
    GROUP BY username, date_utc
),
labeled AS (
    -- Compute forward-looking label (needs future dates visible)
    SELECT up.user_id_hex, d.date_utc,
        COALESCE(SUM(IFF(d.mins > 1, 1, 0)) OVER (
            PARTITION BY d.username ORDER BY d.date_utc
            RANGE BETWEEN INTERVAL '1 DAY' FOLLOWING 
                      AND INTERVAL '7 DAYS' FOLLOWING
        ), 0) AS active_days_in_week
    FROM daily d
    JOIN USER_PROFILES up ON d.username = up.latest_username
),
filtered AS (
    -- Filter AFTER label computation to preserve window accuracy
    SELECT * FROM labeled
    WHERE date_utc <= '{max_date}'
),
sampled AS (
    -- Reproducible HASH-based sampling per day
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY date_utc 
        ORDER BY HASH(user_id_hex || date_utc)
    ) AS rn
    FROM filtered
)
SELECT user_id_hex, date_utc, active_days_in_week 
FROM sampled 
WHERE rn <= {samples_per_day}
```

### Temporal Train/Test Split

Unlike random splitting, temporal splitting prevents data leakage in time-series:

```python
# Sort dates and split by time, not randomly
unique_dates = sorted(dates.unique())
n_train_days = int(len(unique_dates) * 0.8)
cutoff_date = unique_dates[n_train_days - 1]

train_mask = dates <= cutoff_date  # Older data for training
test_mask = dates > cutoff_date    # Newer data for testing
```

### Model Promotion Logic

```
┌─────────────────────────────────────────────────────────────────┐
│                     PROMOTION DECISION                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  IF no existing default version:                                 │
│      → Promote new model (first model)                           │
│                                                                  │
│  ELSE IF new model is already default (auto-set by log_model):  │
│      → Return version name (monitor will be created)             │
│                                                                  │
│  ELSE IF new_rmse < current_rmse:                                │
│      improvement = (current - new) / current                     │
│      IF improvement >= 1%:                                       │
│          → Promote new model                                     │
│      ELSE:                                                       │
│          → Keep current (improvement too small)                  │
│                                                                  │
│  ELSE:                                                           │
│      → Keep current (new model is worse)                         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## Inference Pipeline

### File: `src/inference/predict.py`

### Execution Flow

1. Load configuration and connect to Snowflake
2. Build inference query (users active on inference date)
3. Generate features via Feature Store
4. Load default model from registry
5. Generate predictions
6. Compute SHAP values for explainability
7. Save to PREDICTIONS and PREDICTIONS_SHAP tables
8. Create model monitor if it doesn't exist

### Output Tables

**PREDICTIONS (Narrow Format)**

| Column | Type | Description |
|--------|------|-------------|
| PREDICTION_ID | VARCHAR | Unique UUID per prediction |
| USER_ID_HEX | VARCHAR | User identifier |
| DATE_UTC | DATE | Date the prediction is for |
| PREDICTION_TIMESTAMP | TIMESTAMP_NTZ | When prediction was generated |
| PREDICTED_ACTIVE_DAYS | FLOAT | Model prediction (0-7) |
| ACTUAL_ACTIVE_DAYS | FLOAT | Ground truth (NULL until backfilled) |
| MODEL_NAME | VARCHAR | Model name from registry |
| MODEL_VERSION | VARCHAR | Model version used |
| BATCH_ID | VARCHAR | Batch identifier (YYYYMMDD_HHMMSS) |

**PREDICTIONS_SHAP (Long Format)**

| Column | Type | Description |
|--------|------|-------------|
| PREDICTION_ID | VARCHAR | Links to PREDICTIONS table |
| USER_ID_HEX | VARCHAR | User identifier |
| DATE_UTC | DATE | Prediction date |
| PREDICTION_TIMESTAMP | TIMESTAMP_NTZ | When generated |
| MODEL_NAME | VARCHAR | Model name |
| MODEL_VERSION | VARCHAR | Model version |
| BATCH_ID | VARCHAR | Batch identifier |
| BASE_PREDICTION | FLOAT | SHAP expected value |
| FEATURE_NAME | VARCHAR | Feature name |
| FEATURE_VALUE | FLOAT | Feature value for this prediction |
| SHAP_VALUE | FLOAT | SHAP contribution |

The long format enables:
- Flexible feature addition without schema changes
- Easy aggregation across features
- Efficient storage for sparse contributions

---

## Model Monitoring

### Automatic Monitor Creation

The model monitor is created during inference (after predictions exist):

```python
# In predict.py, after saving predictions
create_monitor_if_not_exists(session, cfg, mv.version_name, warehouse)
```

The function checks if a monitor already exists before creating:

```sql
SHOW MODEL MONITORS LIKE '{monitor_name}'
```

### Monitor Configuration

```sql
CREATE MODEL MONITOR USER_ACTIVITY_MONITOR_{VERSION} WITH
    MODEL = XGBOOST_MODEL
    VERSION = '{version}'
    FUNCTION = 'PREDICT'
    SOURCE = PREDICTIONS              -- Production predictions
    WAREHOUSE = {warehouse}
    REFRESH_INTERVAL = '1 day'
    AGGREGATION_WINDOW = '1 day'
    TIMESTAMP_COLUMN = PREDICTION_TIMESTAMP
    PREDICTION_SCORE_COLUMNS = ('PREDICTED_ACTIVE_DAYS')
    ACTUAL_SCORE_COLUMNS = ('ACTUAL_ACTIVE_DAYS')
```

### Backfill Actuals

**File:** `src/monitoring/backfill_actuals.py`

After 7 days, ground truth is available. This job:
1. Finds predictions with NULL ACTUAL_ACTIVE_DAYS
2. Queries actual user activity for the 7 days following each prediction
3. Counts days with >1 minute usage
4. Updates ACTUAL_ACTIVE_DAYS column

This enables the monitor to compute accuracy metrics (RMSE, MAE).

---

## Deployment

### Container Image

```dockerfile
FROM python:3.10

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY src/ ./src/
COPY config.yaml .

ENV PYTHONPATH=/app

ENTRYPOINT ["python"]
```

### SPCS Authentication

SPCS automatically mounts an OAuth token. The session module auto-detects:

```python
if os.path.exists("/snowflake/session/token"):
    # SPCS environment: Use OAuth token
    token = open("/snowflake/session/token").read()
    session = Session.builder.configs({
        "authenticator": "oauth",
        "token": token,
        ...
    }).create()
else:
    # Local/CI environment: Use private key
    session = Session.builder.configs({
        "private_key_file": "key.p8",
        ...
    }).create()
```

### Task Scheduling

**File:** `tasks/create_tasks.sql`

| Task | Schedule | Script |
|------|----------|--------|
| training_task | Sunday 02:00 UTC | src/training/train.py |
| inference_task | Daily 07:00 UTC | src/inference/predict.py |
| backfill_actuals_task | Daily 08:00 UTC | src/monitoring/backfill_actuals.py |

Task management:
```sql
-- Resume scheduled execution
ALTER TASK training_task RESUME;

-- Run manually
EXECUTE TASK training_task;

-- Check status
SHOW TASKS LIKE '%_task';
```

### CI/CD Pipeline

**File:** `.github/workflows/deploy.yml`

**Trigger:** Manual with environment selection (dev, staging, prod)

**Required Secrets:**
- SNOWFLAKE_ACCOUNT, SNOWFLAKE_USER
- SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
- SNOWFLAKE_WAREHOUSE, SNOWFLAKE_ROLE
- SNOWFLAKE_COMPUTE_POOL
- SNOWFLAKE_PRIVATE_KEY

**Pipeline Steps:**
1. Checkout code
2. Run tests (`pytest tests/ -v`)
3. Build Docker image
4. Push to Snowflake Image Registry
5. Deploy tasks (optional)

---

## Notebooks

The notebooks folder contains experimental work demonstrating the model development process:

| Notebook | Purpose |
|----------|---------|
| **EXPERIMENTS_MASTER** | Complete end-to-end workflow: data loading, EDA, tuning, validation, feature selection |
| **EXPERIMENTS_BASELINE** | Compare 7 baseline models (Linear, Ridge, Lasso, RF, GB, XGBoost, LightGBM) |
| **EXPERIMENTS_WITH_RANDOMIZEDSEARCH** | Hyperparameter tuning with RandomizedSearchCV |
| **EXPERIMENTS_WITH_OPTUNA** | Bayesian optimization with Optuna |
| **FEATURE_STORE** | Feature engineering and Feature View creation |
| **INFERENCE** | Interactive inference demonstration |

All notebooks use:
- Consistent query structure matching production
- Temporal train/test splits (not random)
- HASH-based reproducible sampling

---

## Local Development

### Prerequisites

- Python 3.10+
- Snowflake account with ML features enabled
- Private key for authentication (`key.p8`)

### Setup

```bash
# Clone repository
git clone <repo_url>
cd user_activity_forecasting_project

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export SNOWFLAKE_ACCOUNT=your_account
export SNOWFLAKE_USER=your_username
export SNOWFLAKE_DATABASE=DEV
export SNOWFLAKE_SCHEMA=DATA_SCIENCE
export SNOWFLAKE_WAREHOUSE=ANALYTICS_WH_FLEX
export SNOWFLAKE_ROLE=DATASCIENCE
```

### Running Pipelines

```bash
# Training
PYTHONPATH=. python src/training/train.py

# Inference
PYTHONPATH=. python src/inference/predict.py

# Backfill actuals
PYTHONPATH=. python src/monitoring/backfill_actuals.py

# Run tests
PYTHONPATH=. pytest tests/ -v
```

### Testing with Historical Data

Set `reference_date` in config.yaml:

```yaml
reference_date: "2025-11-19"  # Fixed date for reproducible testing
```

Set to `null` for production (uses current date).

---

## Appendix

### Key Metrics

| Metric | Description | Target |
|--------|-------------|--------|
| **MAE** | Mean Absolute Error (days) | < 1.5 |
| **RMSE** | Root Mean Squared Error | < 1.8 |
| **R²** | Coefficient of determination | > 0.5 |

### Source Data Tables

| Table | Description |
|-------|-------------|
| METRICS_DAILY_USERLEVEL_APP_TIME_SESSIONS | Daily user activity (time in app) |
| USER_PROFILES | User metadata and identifiers |
| ADSHOWEFFECTIVE | Ad impressions and interactions |
| LEGACY_CALL_END | Call quality metrics |
| CALL_RATINGS_COMBINED_SOURCES | User call ratings |
| INCOMING_CALLS / OUTGOING_CALLS | Call logs |
| MESSAGEDELIVERED | Message delivery events |
| PROPERTYMAP | App navigation events |

---

*Documentation last updated: January 2026*
