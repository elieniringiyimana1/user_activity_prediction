"""Tests for user activity forecasting project."""
