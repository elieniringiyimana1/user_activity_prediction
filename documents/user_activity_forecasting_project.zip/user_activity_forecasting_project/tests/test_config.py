"""Tests for config.yaml structure."""

import pytest
import yaml
from pathlib import Path


@pytest.fixture
def config():
    config_path = Path(__file__).parent.parent / "config.yaml"
    with open(config_path) as f:
        return yaml.safe_load(f)


class TestConfigStructure:
    
    def test_has_required_top_level_keys(self, config):
        required = ["feature_store", "model", "training", "tables", "id_columns", "target_column"]
        for key in required:
            assert key in config, f"Missing required key: {key}"
    
    def test_feature_views_have_features(self, config):
        for fv in config["feature_store"]["feature_views"]:
            assert "name" in fv
            assert "version" in fv
            assert "features" in fv, f"Feature view {fv['name']} missing 'features'"
    
    def test_training_config_valid(self, config):
        t = config["training"]
        assert 0 < t["test_size"] < 1
        assert t["lookback_days"] > 0
        assert t["samples_per_day"] > 0
