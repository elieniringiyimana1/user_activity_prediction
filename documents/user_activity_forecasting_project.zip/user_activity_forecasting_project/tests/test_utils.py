"""Tests for src/common/utils.py"""

import pytest


class TestGetFeatureColumns:
    
    def test_extracts_features_from_views(self):
        from src.common.utils import get_feature_columns
        cfg = {
            "feature_store": {
                "feature_views": [
                    {"name": "view1", "version": "1.0", "features": ["A", "B"]},
                    {"name": "view2", "version": "1.0", "features": ["C"]},
                ]
            }
        }
        assert get_feature_columns(cfg) == ["A", "B", "C"]
    
    def test_empty_views_returns_empty(self):
        from src.common.utils import get_feature_columns
        cfg = {"feature_store": {"feature_views": []}}
        assert get_feature_columns(cfg) == []
    
    def test_handles_missing_features_key(self):
        from src.common.utils import get_feature_columns
        cfg = {"feature_store": {"feature_views": [{"name": "test", "version": "1.0"}]}}
        assert get_feature_columns(cfg) == []
