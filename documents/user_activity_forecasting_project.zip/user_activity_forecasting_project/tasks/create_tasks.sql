-- Scheduled Tasks
ALTER TASK IF EXISTS backfill_actuals_task SUSPEND;
ALTER TASK IF EXISTS inference_task SUSPEND;
ALTER TASK IF EXISTS training_task SUSPEND;

-- Training: Weekly on Sunday at 02:00 UTC
CREATE OR REPLACE TASK training_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
  SCHEDULE = 'USING CRON 0 2 * * 0 UTC'
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/training/train.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

-- Inference: Daily at 07:00 UTC
CREATE OR REPLACE TASK inference_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
  SCHEDULE = 'USING CRON 0 7 * * * UTC'
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/inference/predict.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

-- Backfill: Daily at 08:00 UTC
CREATE OR REPLACE TASK backfill_actuals_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
  SCHEDULE = 'USING CRON 0 8 * * * UTC'
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/monitoring/backfill_actuals.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

ALTER TASK training_task RESUME;
ALTER TASK inference_task RESUME;
ALTER TASK backfill_actuals_task RESUME;

-- Feature Store Tasks (manual, run via EXECUTE TASK)
ALTER TASK IF EXISTS fv_ads_task SUSPEND;
ALTER TASK IF EXISTS fv_call_quality_task SUSPEND;
ALTER TASK IF EXISTS fv_call_rating_task SUSPEND;
ALTER TASK IF EXISTS fv_data_usage_task SUSPEND;
ALTER TASK IF EXISTS fv_drawer_event_task SUSPEND;
ALTER TASK IF EXISTS fv_inbound_calls_task SUSPEND;
ALTER TASK IF EXISTS fv_messages_task SUSPEND;
ALTER TASK IF EXISTS fv_nps_rating_task SUSPEND;
ALTER TASK IF EXISTS fv_outbound_calls_task SUSPEND;
ALTER TASK IF EXISTS fv_redial_task SUSPEND;
ALTER TASK IF EXISTS fv_sessions_task SUSPEND;

CREATE OR REPLACE TASK fv_ads_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_ads.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_call_quality_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_call_quality.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_call_rating_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_call_rating.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_data_usage_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_data_usage.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_drawer_event_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_drawer_event.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_inbound_calls_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_inbound_calls.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_messages_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_messages.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_nps_rating_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_nps_rating.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_outbound_calls_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_outbound_calls.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_redial_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_redial.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

CREATE OR REPLACE TASK fv_sessions_task
  WAREHOUSE = ${SNOWFLAKE_WAREHOUSE}
AS
  EXECUTE JOB SERVICE IN COMPUTE POOL ${SNOWFLAKE_COMPUTE_POOL}
  FROM SPECIFICATION $$
  spec:
    containers:
    - name: main
      image: ${IMAGE_PATH}
      args: [src/feature_store/fv_sessions.py]
      env:
        SNOWFLAKE_DATABASE: ${SNOWFLAKE_DATABASE}
        SNOWFLAKE_SCHEMA: ${SNOWFLAKE_SCHEMA}
        SNOWFLAKE_WAREHOUSE: ${SNOWFLAKE_WAREHOUSE}
        SNOWFLAKE_ROLE: ${SNOWFLAKE_ROLE}
  $$;

-- Feature view tasks are manual (no schedule) - run via: EXECUTE TASK fv_ads_task;
-- They remain suspended and are executed on-demand
