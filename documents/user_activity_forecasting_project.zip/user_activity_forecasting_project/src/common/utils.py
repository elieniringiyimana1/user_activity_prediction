"""Config loading, model creation, and model promotion utilities."""

import logging
import os
import yaml
from datetime import datetime
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def load_config():
    """Load config.yaml from current dir, /app/, or project root."""
    project_root = Path(__file__).parent.parent.parent
    
    if Path("config.yaml").exists():
        path = Path("config.yaml")
    elif Path("/app/config.yaml").exists():
        path = Path("/app/config.yaml")
    elif (project_root / "config.yaml").exists():
        path = project_root / "config.yaml"
    else:
        raise FileNotFoundError("config.yaml not found")
    
    with open(path) as f:
        return yaml.safe_load(f)


_cfg = None

def get_config():
    """Get config (cached)."""
    global _cfg
    if _cfg is None:
        _cfg = load_config()
    return _cfg


def get_reference_date(cfg=None):
    """Get reference date from config, or current date if null."""
    if cfg is None:
        cfg = get_config()
    ref = cfg.get("reference_date")
    if ref:
        return datetime.strptime(ref, "%Y-%m-%d").date()
    return datetime.now().date()


def create_model(cfg):
    """Create model from config using dynamic import."""
    import importlib
    
    class_path = cfg["model"]["class"]
    module_path, class_name = class_path.rsplit(".", 1)
    
    module = importlib.import_module(module_path)
    model_class = getattr(module, class_name)
    
    params = {k: v for k, v in cfg["model"]["hyperparameters"].items() if v is not None}
    return model_class(**params)


def get_feature_columns(cfg):
    """Derive feature columns from feature view configs."""
    all_features = []
    for fv in cfg["feature_store"]["feature_views"]:
        all_features.extend(fv.get("features", []))
    return all_features


def get_feature_views(fs, cfg):
    """Get sliced feature views - only fetches needed features."""
    return [
        fs.get_feature_view(name=fv["name"], version=fv["version"]).slice(fv["features"])
        for fv in cfg["feature_store"]["feature_views"]
        if fv.get("features")
    ]


def promote_if_better(session, registry, model_name, new_rmse, threshold=0.01):
    """Promote new model if it beats current default by threshold.
    
    Returns:
        str or None: Version name if promoted, None otherwise.
    """
    versions = registry.get_model(model_name).show_versions()
    newest = versions.sort_values("created_on", ascending=False).iloc[0]["name"]
    
    try:
        current = registry.get_model(model_name).default
        current_rmse = current.show_metrics().get('rmse')
    except:
        current_rmse = None
    
    if current_rmse is None:
        session.sql(f"ALTER MODEL {model_name} SET DEFAULT_VERSION = {newest}").collect()
        logger.info(f"First model - set {newest} as default")
        return newest
    
    if current.version_name == newest:
        logger.info(f"New version {newest} is already default")
        return newest
    
    if new_rmse < current_rmse:
        improvement = (current_rmse - new_rmse) / current_rmse
        if improvement >= threshold:
            session.sql(f"ALTER MODEL {model_name} SET DEFAULT_VERSION = {newest}").collect()
            logger.info(f"Promoted {newest} ({improvement*100:.1f}% improvement)")
            return newest
        else:
            logger.info(f"Improvement {improvement*100:.1f}% below threshold")
    else:
        logger.info(f"Current model better ({current_rmse:.4f} vs {new_rmse:.4f})")
    
    return None
