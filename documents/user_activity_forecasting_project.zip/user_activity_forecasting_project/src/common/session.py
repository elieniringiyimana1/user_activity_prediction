"""Snowflake session management."""

import logging
import os

from snowflake.snowpark import Session
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def get_snowflake_connection():
    """Get Snowflake session. Auto-detects SPCS vs CI/CD vs local."""
    token_path = "/snowflake/session/token"
    
    if os.path.exists(token_path):
        with open(token_path, "r") as f:
            token = f.read().strip()
        
        session = Session.builder.configs({
            "host": os.getenv("SNOWFLAKE_HOST"),
            "account": os.getenv("SNOWFLAKE_ACCOUNT"),
            "authenticator": "oauth",
            "token": token,
            "database": os.getenv("SNOWFLAKE_DATABASE"),
            "schema": os.getenv("SNOWFLAKE_SCHEMA"),
            "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE"),
            "role": os.getenv("SNOWFLAKE_ROLE"),
        }).create()
        logger.info("Connected via SPCS")
        return session
    
    session = Session.builder.configs({
        "account": os.environ["SNOWFLAKE_ACCOUNT"],
        "user": os.environ["SNOWFLAKE_USER"],
        "database": os.getenv("SNOWFLAKE_DATABASE"),
        "schema": os.getenv("SNOWFLAKE_SCHEMA"),
        "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE"),
        "role": os.getenv("SNOWFLAKE_ROLE"),
        "private_key_file": os.getenv("SNOWFLAKE_PRIVATE_KEY_FILE", "key.p8"),
    }).create()
    logger.info("Connected via private key")
    return session


if __name__ == '__main__':
    get_snowflake_connection()
