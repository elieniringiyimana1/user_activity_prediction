"""User Activity Forecasting Package."""
