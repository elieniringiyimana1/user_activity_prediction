"""Model training pipeline."""

import logging
import os
import numpy as np
import time
from datetime import timedelta

from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from snowflake.ml.experiment import ExperimentTracking
from snowflake.ml.feature_store import FeatureStore
from snowflake.ml.registry import Registry

from src.common.session import get_snowflake_connection
from src.common.utils import get_config, get_reference_date, create_model, promote_if_better, get_feature_columns, get_feature_views

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def build_training_query(cfg):
    today = get_reference_date(cfg)
    lookback = cfg["training"]["lookback_days"]
    maturity = cfg["training"]["label_maturity_days"]
    horizon = cfg["training"]["prediction_horizon_days"]
    samples_per_day = cfg["training"]["samples_per_day"]
    
    min_date = today - timedelta(days=lookback)
    max_date = today - timedelta(days=maturity)
    
    return f"""
WITH daily AS (
    SELECT username, date_utc, SUM(time_in_app_mins_per_day) AS mins
    FROM {cfg["tables"]["activity_source"]}
    WHERE date_utc >= '{min_date}'
    GROUP BY username, date_utc
),
labeled AS (
    SELECT up.user_id_hex, d.date_utc,
        COALESCE(SUM(IFF(d.mins > 1, 1, 0)) OVER (
            PARTITION BY d.username ORDER BY d.date_utc
            RANGE BETWEEN INTERVAL '1 DAY' FOLLOWING AND INTERVAL '{horizon} DAYS' FOLLOWING
        ), 0) AS active_days_in_week
    FROM daily d
    JOIN {cfg["tables"]["user_lookup"]} up ON d.username = up.latest_username
),
filtered AS (
    SELECT * FROM labeled
    WHERE date_utc <= '{max_date}'
),
sampled AS (
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY date_utc 
        ORDER BY HASH(user_id_hex || date_utc)
    ) AS rn
    FROM filtered
)
SELECT user_id_hex, date_utc, active_days_in_week 
FROM sampled 
WHERE rn <= {samples_per_day}
"""


def main():
    cfg = get_config()
    logger.info(f"Model: {cfg['model']['class']}")
    
    session = get_snowflake_connection()
    db = os.getenv("SNOWFLAKE_DATABASE")
    schema = os.getenv("SNOWFLAKE_SCHEMA")
    warehouse = os.getenv("SNOWFLAKE_WAREHOUSE")
    
    registry = Registry(session=session, database_name=db, schema_name=schema)
    exp = ExperimentTracking(session=session)
    exp.set_experiment(cfg["training"]["experiment_name"])
    fs = FeatureStore(session=session, database=db, name=cfg["feature_store"]["name"], default_warehouse=warehouse)
    
    feature_views = get_feature_views(fs, cfg)
    spine_df = session.sql(build_training_query(cfg))
    
    df = fs.generate_training_set(
        spine_df=spine_df,
        features=feature_views,
        spine_label_cols=cfg["target_column"],
    )
    
    df = df.to_pandas().fillna(0)
    
    feature_cols = get_feature_columns(cfg)
    target_col = cfg["target_column"]
    id_cols = cfg["id_columns"]
    df = df[id_cols + [target_col] + feature_cols]
    logger.info(f"Training data: {len(df)} rows")
    
    dates = df['DATE_UTC']
    unique_dates = sorted(dates.unique())
    n_train_days = int(len(unique_dates) * (1 - cfg["training"]["test_size"]))
    cutoff_date = unique_dates[n_train_days - 1]
    
    train_mask = dates <= cutoff_date
    test_mask = dates > cutoff_date
    
    X = df[feature_cols]
    y = df[target_col]
    
    X_train = X[train_mask].reset_index(drop=True)
    X_test = X[test_mask].reset_index(drop=True)
    y_train = y[train_mask].reset_index(drop=True)
    y_test = y[test_mask].reset_index(drop=True)
    
    logger.info(f"Train: {len(X_train)} rows ({n_train_days} days, <= {cutoff_date})")
    logger.info(f"Test:  {len(X_test)} rows ({len(unique_dates) - n_train_days} days, > {cutoff_date})")
    
    preprocess = ColumnTransformer([("num", StandardScaler(), X.select_dtypes(include=['number']).columns)])
    model = create_model(cfg)
    pipeline = Pipeline([("preprocess", preprocess), ("model", model)])
    
    start = time.time()
    pipeline.fit(X_train, y_train)
    train_time = time.time() - start
    
    y_pred = pipeline.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    mae = mean_absolute_error(y_test, y_pred)
    logger.info(f"RMSE: {rmse:.4f}, MAE: {mae:.4f}, Time: {train_time:.1f}s")
    
    with exp.start_run():
        exp.log_metric("rmse", rmse)
        exp.log_metric("mae", mae)
        exp.log_param("model_type", cfg["model"]["display_name"])
        exp.log_param("n_train", len(X_train))
        exp.log_param("n_test", len(X_test))
        exp.log_param("n_features", X.shape[1])
        exp.log_param("train_days", n_train_days)
        exp.log_param("cutoff_date", str(cutoff_date))
        exp.log_model(model=pipeline, model_name=f"{cfg['model']['display_name']}_model", 
                      metrics={"rmse": rmse, "mae": mae}, sample_input_data=X_train.head())
    
    promote_if_better(session, registry, cfg["model"]["registry_name"], rmse, cfg["training"]["improvement_threshold"])
    
    logger.info("Training complete")


if __name__ == '__main__':
    main()
