"""Feature View: user_features_redial"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_redial"
VERSION = "1.2"

QUERY = """
WITH redials AS (
    SELECT
        username, created_at, call_direction, from_contact_value, to_contact_value,
        callduration, client_type,
        LAG(client_type) OVER (PARTITION BY username ORDER BY created_at) AS prev_client_type,
        LAG(callduration) OVER (PARTITION BY username ORDER BY created_at) AS prev_call_duration,
        LAG(from_contact_value) OVER (PARTITION BY username ORDER BY created_at) AS prev_from_contact,
        LAG(to_contact_value) OVER (PARTITION BY username ORDER BY created_at) AS prev_to_contact,
        (created_at < DATEADD(second, NVL(LAG(callduration) OVER (PARTITION BY username ORDER BY created_at), 0) + 60, 
                              LAG(created_at) OVER (PARTITION BY username ORDER BY created_at))
         AND LAG(callduration) OVER (PARTITION BY username ORDER BY created_at) > 5
         AND call_direction IN ('outgoing', 'incoming')
         AND ((from_contact_value = LAG(from_contact_value) OVER (PARTITION BY username ORDER BY created_at) 
               AND to_contact_value = LAG(to_contact_value) OVER (PARTITION BY username ORDER BY created_at))
              OR (from_contact_value = LAG(to_contact_value) OVER (PARTITION BY username ORDER BY created_at) 
                  AND to_contact_value = LAG(from_contact_value) OVER (PARTITION BY username ORDER BY created_at)))
        ) AS redial
    FROM {src}.ONCALLEND_CALLBACKS
),
agg AS (
    SELECT
        created_at::DATE AS date_utc,
        up.user_id_hex,
        COALESCE(client_type, prev_client_type) AS client_type_redials,
        COUNT_IF(redial) AS cnt
    FROM redials
    JOIN {src}.user_profiles up ON username = up.latest_username
    GROUP BY ALL
),
pivoted AS (
    SELECT * FROM agg
    PIVOT (MAX(cnt) FOR client_type_redials IN (
        'TN_IOS_FREE' AS tn_ios_free,
        null AS null_name,
        'TN_ANDROID' AS tn_android,
        '2L_ANDROID' AS android
    ))
)
SELECT date_utc, user_id_hex,
    COALESCE(tn_ios_free, 0) AS TN_IOS_FREE,
    COALESCE(null_name, 0) AS NULL_NAME,
    COALESCE(tn_android, 0) AS TN_ANDROID,
    COALESCE(android, 0) AS ANDROID
FROM pivoted
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
