"""Feature store utilities."""

import logging
import os
from snowflake.ml.feature_store import FeatureStore, Entity, FeatureView, CreationMode
from src.common.session import get_snowflake_connection
from src.common.utils import get_config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def get_source_prefix():
    """Get source schema prefix (database.schema)."""
    db = os.getenv("SNOWFLAKE_DATABASE")
    schema = os.getenv("SNOWFLAKE_SCHEMA")
    return f"{db}.{schema}"


def get_feature_store():
    """Get Feature Store connection."""
    cfg = get_config()
    session = get_snowflake_connection()
    
    fs = FeatureStore(
        session=session,
        database=os.getenv("SNOWFLAKE_DATABASE"),
        name=cfg["feature_store"]["name"],
        default_warehouse=os.getenv("SNOWFLAKE_WAREHOUSE"),
        creation_mode=CreationMode.CREATE_IF_NOT_EXIST
    )
    return fs, session


def get_entity(fs):
    """Get or create user entity."""
    entity = Entity(
        name="USER_ENTITY",
        join_keys=["USER_ID_HEX", "DATE_UTC"],
        desc="User entity with daily granularity"
    )
    fs.register_entity(entity)
    return entity


def register_feature_view(fs, session, entity, name, query, version):
    """Register a feature view. Query should use {src} placeholder."""
    try:
        existing = fs.get_feature_view(name=name, version=version)
        logger.info(f"Feature view {name} v{version} already exists, skipping")
        return existing
    except:
        pass
    
    resolved_query = query.format(src=get_source_prefix())
    df = session.sql(resolved_query)
    
    fv = FeatureView(
        name=name,
        entities=[entity],
        feature_df=df,
        desc=f"Features: {name}"
    )
    
    fs.register_feature_view(feature_view=fv, version=version, overwrite=False)
    logger.info(f"Registered {name} v{version}")
    return fv
