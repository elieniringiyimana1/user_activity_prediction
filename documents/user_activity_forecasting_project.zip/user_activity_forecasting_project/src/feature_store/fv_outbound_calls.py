"""Feature View: user_features_outbound_calls"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_outbound_calls"
VERSION = "1.2"

QUERY = """
SELECT
    oc.date_utc,
    up.user_id_hex,
    COALESCE(COUNT(1), 0)::DECIMAL(10,2) AS COUNT,
    COALESCE(SUM(oc.call_secs), 0)::DECIMAL(10,2) AS DURATION_SEC,
    COALESCE(NULLIFZERO(COUNT_IF(oc.call_secs = 0)), 0)::DECIMAL(10,2) AS UNANSWERED,
    COALESCE(NULLIFZERO(COUNT_IF(oc.call_secs > 15)), 0)::DECIMAL(10,2) AS COUNT_OVER_15S,
    COALESCE(NULLIFZERO(COUNT_IF(oc.hangup_cause = 'MEDIA_TIMEOUT')), 0)::DECIMAL(10,2) AS MEDIA_TIMEOUT
FROM {src}.outgoing_calls oc
JOIN {src}.user_profiles up ON oc.username = up.latest_username
WHERE up.user_id_hex <> '000-00-000-000000000'
GROUP BY oc.date_utc, up.user_id_hex
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
