"""Feature View: user_features_nps_rating"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_nps_rating"
VERSION = "1.2"

QUERY = """
SELECT
    date_utc,
    user_id_hex,
    COALESCE(COUNT(call_rating), 0)::FLOAT AS NPS_CALL_RATING_COUNT,
    COALESCE(AVG(call_rating), 0)::FLOAT AS NPS_AVG_CALL_RATING,
    COALESCE(MAX(call_rating), 0)::FLOAT AS NPS_MAX_CALL_RATING,
    COALESCE(MIN(call_rating), 0)::FLOAT AS NPS_MIN_CALL_RATING
FROM {src}.call_ratings_combined_sources
WHERE call_rating > 0
    AND user_id_hex <> '000-00-000-000000000'
GROUP BY date_utc, user_id_hex
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
