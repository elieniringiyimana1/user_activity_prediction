"""Feature View: user_features_ads"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_ads"
VERSION = "1.2"

QUERY = """
WITH initial_table as (
    SELECT date_utc, user_id_hex,
        SPLIT_PART("payload.ad_event_data.ad_unit_id", '_', -1) AS feature_name,
        count(*) AS feature_value_numeric
    FROM {src}.adshoweffective
    WHERE user_id_hex IS NOT NULL AND date_utc IS NOT NULL
    GROUP BY ALL
),
pivot_table as (
    SELECT * FROM initial_table
    PIVOT (MAX(feature_value_numeric) FOR feature_name IN (
        'conversationendinterstitial', 'p1smsrichmedia', 'postcallnativevideo',
        'callendinterstitial', 'unifiedinstreamlarge', 'p1ad', 'unifiedinstreamsmall',
        'banner', 'callscreensmall', 'keyboardmedrect', 'iaprewardedvideo',
        'p1smsnative', 'textinstreamsmall', 'textinstreamlarge', 'tabletmedrect',
        'callscreenlarge', 'rewardedvideo'
    ))
)
SELECT date_utc, user_id_hex,
    COALESCE(conversationendinterstitial, 0) as CONVERSATIONENDINTERSTITIAL,
    COALESCE(p1smsrichmedia, 0) as P1SMSRICHMEDIA,
    COALESCE(postcallnativevideo, 0) as POSTCALLNATIVEVIDEO,
    COALESCE(callendinterstitial, 0) as CALLENDINTERSTITIAL,
    COALESCE(unifiedinstreamlarge, 0) as UNIFIEDINSTREAMLARGE,
    COALESCE(p1ad, 0) as P1AD,
    COALESCE(unifiedinstreamsmall, 0) as UNIFIEDINSTREAMSMALL,
    COALESCE(banner, 0) as BANNER,
    COALESCE(callscreensmall, 0) as CALLSCREENSMALL,
    COALESCE(keyboardmedrect, 0) as KEYBOARDMEDRECT,
    COALESCE(iaprewardedvideo, 0) as IAPREWARDEDVIDEO,
    COALESCE(p1smsnative, 0) as P1SMSNATIVE,
    COALESCE(textinstreamsmall, 0) as TEXTINSTREAMSMALL,
    COALESCE(textinstreamlarge, 0) as TEXTINSTREAMLARGE,
    COALESCE(tabletmedrect, 0) as TABLETMEDRECT,
    COALESCE(callscreenlarge, 0) as CALLSCREENLARGE,
    COALESCE(rewardedvideo, 0) as REWARDEDVIDEO
FROM pivot_table
"""


def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)


if __name__ == '__main__':
    main()
