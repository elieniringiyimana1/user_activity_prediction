"""Feature View: user_features_call_quality"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_call_quality"
VERSION = "1.2"

QUERY = """
SELECT date_utc, user_id_hex,
    COALESCE(COUNT_IF(COALESCE(num_bad_mos_periods, 0) > 0), 0)::FLOAT AS CALLS_WITH_BAD_MOS,
    COALESCE(AVG(computed_mos), 0)::FLOAT AS AVERAGE_MOS,
    COALESCE(MAX(RTP_SETUP_TIME), 0)::FLOAT AS MAX_RTP_SETUP_TIME
FROM {src}.legacy_call_end
WHERE leg_a_call_id NOT LIKE 'no_active_calls%'
    AND lower(call_direction) IN ('inbound', 'outbound')
    AND call_duration > 0
    AND user_id_hex <> '000-00-000-000000000'
GROUP BY date_utc, user_id_hex
"""


def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)


if __name__ == '__main__':
    main()
