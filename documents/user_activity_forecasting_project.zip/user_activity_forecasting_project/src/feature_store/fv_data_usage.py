"""Feature View: user_features_data_usage"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_data_usage"
VERSION = "1.2"

QUERY = """
SELECT 
    c.date_utc,
    up.user_id_hex,
    COALESCE(SUM(c.mb_usage), 0) AS MB_USAGE
FROM {src}.cost_user_daily_tmobile_cost c
JOIN {src}.user_profiles up ON c.username = up.latest_username
WHERE up.user_id_hex <> '000-00-000-000000000'
GROUP BY c.date_utc, up.user_id_hex
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
