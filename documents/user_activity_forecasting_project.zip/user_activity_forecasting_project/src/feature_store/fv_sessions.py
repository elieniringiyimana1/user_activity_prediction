"""Feature View: user_features_sessions"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_sessions"
VERSION = "1.2"

QUERY = """
WITH initial_table AS (
    SELECT 
        m.date_utc,
        up.user_id_hex,
        SUM(m.time_in_app_mins_per_day::DECIMAL(18,4)) AS time_in_app_mins,
        DATEDIFF(day, MIN(up.registered_at), m.date_utc)::DECIMAL(18,0) AS tenure_days,
        SUM(m.num_sessions::DECIMAL(18,0)) AS session_count
    FROM {src}.metrics_daily_userlevel_app_time_sessions m 
    JOIN {src}.user_profiles up ON m.username = up.latest_username
    WHERE up.user_id_hex <> '000-00-000-000000000'
        AND m.client_type IN ('TN_IOS_FREE', 'TN_ANDROID')
    GROUP BY ALL
),
features AS (
    SELECT
        date_utc, user_id_hex,
        COALESCE(time_in_app_mins, 0) AS time_in_app_mins,
        COALESCE(tenure_days, 0) AS tenure_days,
        COALESCE(session_count, 0) AS session_count,
        IFF(COALESCE(time_in_app_mins, 0) > 1, 1, 0) AS is_active_day
    FROM initial_table
),
rollups AS (
    SELECT
        date_utc, user_id_hex, time_in_app_mins, tenure_days, session_count,
        COALESCE(SUM(is_active_day) OVER (
            PARTITION BY user_id_hex ORDER BY date_utc
            RANGE BETWEEN INTERVAL '7 DAYS' PRECEDING AND INTERVAL '1 DAY' PRECEDING
        ), 0) AS active_days_prev_7,
        COALESCE(SUM(is_active_day) OVER (
            PARTITION BY user_id_hex ORDER BY date_utc
            RANGE BETWEEN INTERVAL '14 DAYS' PRECEDING AND INTERVAL '1 DAY' PRECEDING
        ), 0) AS active_days_prev_14,
        COALESCE(SUM(is_active_day) OVER (
            PARTITION BY user_id_hex ORDER BY date_utc
            RANGE BETWEEN INTERVAL '30 DAYS' PRECEDING AND INTERVAL '1 DAY' PRECEDING
        ), 0) AS active_days_prev_30,
        COALESCE(SUM(is_active_day) OVER (
            PARTITION BY user_id_hex ORDER BY date_utc
            RANGE BETWEEN INTERVAL '90 DAYS' PRECEDING AND INTERVAL '1 DAY' PRECEDING
        ), 0) AS active_days_prev_90
    FROM features
)
SELECT
    date_utc, user_id_hex,
    time_in_app_mins AS TIME_IN_APP_MINS,
    tenure_days AS TENURE_DAYS,
    session_count AS SESSION_COUNT,
    active_days_prev_7 AS ACTIVE_DAYS_PREV_7,
    active_days_prev_14 AS ACTIVE_DAYS_PREV_14,
    active_days_prev_30 AS ACTIVE_DAYS_PREV_30,
    active_days_prev_90 AS ACTIVE_DAYS_PREV_90
FROM rollups
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
