"""Feature View: user_features_drawer_event"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_drawer_event"
VERSION = "1.2"

QUERY = """
WITH initial_tbl as ( 
    SELECT
        date_utc,
        user_id_hex,
        '' || "payload.properties.DrawerEvent" AS feature_name,
        COUNT(*) AS feature_value_numeric
    FROM {src}.PROPERTYMAP
    WHERE "payload.properties.DrawerEvent" IS NOT NULL
    GROUP BY ALL
),
pivot_table as (
    SELECT * FROM initial_tbl
    PIVOT (MAX(feature_value_numeric) FOR feature_name IN (
        'ConversationsTapped' as ConversationsTapped,
        'Use TextNow without WifiTapped' as UseTextNowwithoutWifiTapped,
        'ContactsTapped' as ContactsTapped,
        'AdFreePlusTapped' as AdFreePlusTapped,
        'CallHistoryTapped' as CallHistoryTapped,
        'My WalletTapped' as My_WalletTapped,
        'AdFreeLiteTapped' as AdFreeLiteTapped,
        'WorldNewsTapped' as WorldNewsTapped,
        'MyWalletTapped' as MyWalletTapped,
        'Earn Credits & RewardsTapped' as EarnCreditsRewardsTapped,
        'BlogTapped' as BloggedTapped,
        'TextNow NewsTapped' as TNNewsTapped,
        'Activate your SIM CardTapped' as ActivateSimCardTapped,
        'ShareAppTapped' as ShareAppTapped,
        'Use TextNow Without Wi-Fi Tapped' as TNwoWiFiTapped,
        'EarnCreditsTapped' as EarnCreditsTapped,
        'Close' as CloseTapped,
        'My StoreTapped' as MyStoreTapped,
        'MyOffersTapped' as MyOffersTapped,
        'TextNow PerksTapped' as TNPerksTapped,
        'SupportTapped' as SupportTapped,
        'Get Free StuffTapped' as GetFreeStuffTapped,
        'Open' as OpenTapped,
        'Remove Ads & Loc NumberTapped' as RemoveAdsLocNumTapped,
        'ActiveSIMTapped' as ActiveSIMTapped,
        'ShareNumberTapped' as ShareNumberTapped,
        'Priority Support EmailTapped' as PriorityEmailTapped,
        'TextNowPhonesTapped' as TNPhonesTapped,
        'Use TextNow without WiFiTapped' as UseTNwoWifiTapped,
        'SettingsTapped' as SettingsTapped,
        'Get High-Speed DataTapped' as HighSpeedDataTapped,
        'RemoveAdsTapped' as RemoveAdsTapped,
        'FreeCoverageTapped' as FreeCoverageTapped,
        'Use TextNow Without Wi-FiTapped' as UTNwoWIFITapped
    ))
)
SELECT date_utc, user_id_hex,
    COALESCE(ConversationsTapped, 0) AS CONVERSATIONSTAPPED,
    COALESCE(UseTextNowwithoutWifiTapped, 0) AS USETEXTNOWWITHOUTWIFITAPPED,
    COALESCE(ContactsTapped, 0) AS CONTACTSTAPPED,
    COALESCE(AdFreePlusTapped, 0) AS ADFREEPLUSTAPPED,
    COALESCE(CallHistoryTapped, 0) AS CALLHISTORYTAPPED,
    COALESCE(My_WalletTapped, 0) AS MY_WALLETTAPPED,
    COALESCE(AdFreeLiteTapped, 0) AS ADFREELITETAPPED,
    COALESCE(WorldNewsTapped, 0) AS WORLDNEWSTAPPED,
    COALESCE(MyWalletTapped, 0) AS MYWALLETTAPPED,
    COALESCE(EarnCreditsRewardsTapped, 0) AS EARNCREDITSREWARDSTAPPED,
    COALESCE(BloggedTapped, 0) AS BLOGGEDTAPPED,
    COALESCE(TNNewsTapped, 0) AS TNNEWSTAPPED,
    COALESCE(ActivateSimCardTapped, 0) AS ACTIVATESIMCARDTAPPED,
    COALESCE(ShareAppTapped, 0) AS SHAREAPPTAPPED,
    COALESCE(TNwoWiFiTapped, 0) AS TNWOWIFITAPPED,
    COALESCE(EarnCreditsTapped, 0) AS EARNCREDITSTAPPED,
    COALESCE(CloseTapped, 0) AS CLOSETAPPED,
    COALESCE(MyStoreTapped, 0) AS MYSTORETAPPED,
    COALESCE(MyOffersTapped, 0) AS MYOFFERSTAPPED,
    COALESCE(TNPerksTapped, 0) AS TNPERKSTAPPED,
    COALESCE(SupportTapped, 0) AS SUPPORTTAPPED,
    COALESCE(GetFreeStuffTapped, 0) AS GETFREESTUFFTAPPED,
    COALESCE(OpenTapped, 0) AS OPENTAPPED,
    COALESCE(RemoveAdsLocNumTapped, 0) AS REMOVEADSLOCNUMTAPPED,
    COALESCE(ActiveSIMTapped, 0) AS ACTIVESIMTAPPED,
    COALESCE(ShareNumberTapped, 0) AS SHARENUMBERTAPPED,
    COALESCE(PriorityEmailTapped, 0) AS PRIORITYEMAILTAPPED,
    COALESCE(TNPhonesTapped, 0) AS TNPHONESTAPPED,
    COALESCE(UseTNwoWifiTapped, 0) AS USETNWOWIFITAPPED,
    COALESCE(SettingsTapped, 0) AS SETTINGSTAPPED,
    COALESCE(HighSpeedDataTapped, 0) AS HIGHSPEEDDATATAPPED,
    COALESCE(RemoveAdsTapped, 0) AS REMOVEADSTAPPED,
    COALESCE(FreeCoverageTapped, 0) AS FREECOVERAGETAPPED,
    COALESCE(UTNwoWIFITapped, 0) AS UTNWOWIFITAPPED
FROM pivot_table
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
