"""Feature View: user_features_messages"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_messages"
VERSION = "1.2"

QUERY = """
WITH messages AS (
    SELECT
        date_utc, user_id_hex,
        "payload.message_direction" || '|' || 
        CASE WHEN "payload.message_direction" = 'MESSAGE_DIRECTION_INBOUND'
             AND "payload.origin"[0] = 'mailto:support@enflick.com' 
             THEN 'MESSAGE_TYPE_SYSTEM_TEXT' ELSE "payload.content_type" END 
        || '|' || "payload.routing_decision" AS combo,
        COUNT(*) AS cnt
    FROM {src}.MESSAGEDELIVERED
    WHERE NOT (instance_id LIKE 'TN_SERVER_%' 
               AND "payload.content_type" IN ('MESSAGE_TYPE_TEXT','MESSAGE_TYPE_IMAGE','MESSAGE_TYPE_VIDEO','MESSAGE_TYPE_AUDIO'))
        AND user_id_hex IS NOT NULL
    GROUP BY ALL
    HAVING cnt > 0
),
pivoted AS (
    SELECT * FROM messages
    PIVOT (SUM(cnt) FOR combo IN (
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_AUDIO|ROUTING_DECISION_ALLOW' AS inbound_audio_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_IMAGE|ROUTING_DECISION_ALLOW' AS inbound_image_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_MISSED_CALL|ROUTING_DECISION_UNKNOWN' AS inbound_missed_unk,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_SYSTEM_TEXT|ROUTING_DECISION_ALLOW' AS inbound_sys_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_TEXT|ROUTING_DECISION_ALLOW' AS inbound_text_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_TEXT|ROUTING_DECISION_DENY' AS inbound_text_deny,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_TEXT_FILE|ROUTING_DECISION_ALLOW' AS inbound_file_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_UNKNOWN|ROUTING_DECISION_ALLOW' AS inbound_unk_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_VIDEO|ROUTING_DECISION_ALLOW' AS inbound_video_allow,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_VOICEMAIL|ROUTING_DECISION_UNKNOWN' AS inbound_voicemail_unk,
        'MESSAGE_DIRECTION_INBOUND|MESSAGE_TYPE_VOICEMAIL_TRANSCRIPT|ROUTING_DECISION_UNKNOWN' AS inbound_voicemailtr_unk,
        'MESSAGE_DIRECTION_OUTBOUND|MESSAGE_TYPE_AUDIO|ROUTING_DECISION_ALLOW' AS outbound_audio_allow,
        'MESSAGE_DIRECTION_OUTBOUND|MESSAGE_TYPE_IMAGE|ROUTING_DECISION_ALLOW' AS outbound_image_allow,
        'MESSAGE_DIRECTION_OUTBOUND|MESSAGE_TYPE_IMAGE|ROUTING_DECISION_DENY' AS outbound_image_deny,
        'MESSAGE_DIRECTION_OUTBOUND|MESSAGE_TYPE_TEXT|ROUTING_DECISION_ALLOW' AS outbound_text_allow,
        'MESSAGE_DIRECTION_OUTBOUND|MESSAGE_TYPE_TEXT|ROUTING_DECISION_DENY' AS outbound_text_deny,
        'MESSAGE_DIRECTION_OUTBOUND|MESSAGE_TYPE_VIDEO|ROUTING_DECISION_ALLOW' AS outbound_video_allow
    ))
)
SELECT date_utc, user_id_hex,
    COALESCE(inbound_audio_allow, 0) AS INBOUND_AUDIO_ALLOW,
    COALESCE(inbound_image_allow, 0) AS INBOUND_IMAGE_ALLOW,
    COALESCE(inbound_missed_unk, 0) AS INBOUND_MISSED_UNK,
    COALESCE(inbound_sys_allow, 0) AS INBOUND_SYS_ALLOW,
    COALESCE(inbound_text_allow, 0) AS INBOUND_TEXT_ALLOW,
    COALESCE(inbound_text_deny, 0) AS INBOUND_TEXT_DENY,
    COALESCE(inbound_file_allow, 0) AS INBOUND_FILE_ALLOW,
    COALESCE(inbound_unk_allow, 0) AS INBOUND_UNK_ALLOW,
    COALESCE(inbound_video_allow, 0) AS INBOUND_VIDEO_ALLOW,
    COALESCE(inbound_voicemail_unk, 0) AS INBOUND_VOICEMAIL_UNK,
    COALESCE(inbound_voicemailtr_unk, 0) AS INBOUND_VOICEMAILTR_UNK,
    COALESCE(outbound_audio_allow, 0) AS OUTBOUND_AUDIO_ALLOW,
    COALESCE(outbound_image_allow, 0) AS OUTBOUND_IMAGE_ALLOW,
    COALESCE(outbound_image_deny, 0) AS OUTBOUND_IMAGE_DENY,
    COALESCE(outbound_text_allow, 0) AS OUTBOUND_TEXT_ALLOW,
    COALESCE(outbound_text_deny, 0) AS OUTBOUND_TEXT_DENY,
    COALESCE(outbound_video_allow, 0) AS OUTBOUND_VIDEO_ALLOW
FROM pivoted
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
