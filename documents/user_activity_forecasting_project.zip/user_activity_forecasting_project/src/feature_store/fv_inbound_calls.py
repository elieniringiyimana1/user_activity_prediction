"""Feature View: user_features_inbound_calls"""

from src.feature_store.base import get_feature_store, get_entity, register_feature_view

NAME = "user_features_inbound_calls"
VERSION = "1.2"

QUERY = """
SELECT
    ic.date_utc,
    up.user_id_hex,
    COALESCE(COUNT(1), 0)::DECIMAL(10,2) AS INBOUND_COUNT,
    COALESCE(SUM(ic.call_secs), 0)::DECIMAL(10,2) AS INBOUND_DURATION_SEC,
    COALESCE(NULLIFZERO(COUNT_IF(ic.call_secs = 0)), 0)::DECIMAL(10,2) AS INBOUND_UNANSWERED,
    COALESCE(NULLIFZERO(COUNT_IF(ic.call_secs > 15)), 0)::DECIMAL(10,2) AS INBOUND_COUNT_OVER_15S,
    COALESCE(NULLIFZERO(COUNT_IF(ic.hangup_cause = 'MEDIA_TIMEOUT')), 0)::DECIMAL(10,2) AS INBOUND_MEDIA_TIMEOUT
FROM {src}.incoming_calls ic
JOIN {src}.user_profiles up ON ic.username = up.latest_username
WHERE up.user_id_hex <> '000-00-000-000000000'
GROUP BY ic.date_utc, up.user_id_hex
"""

def main():
    fs, session = get_feature_store()
    entity = get_entity(fs)
    register_feature_view(fs, session, entity, NAME, QUERY, VERSION)

if __name__ == '__main__':
    main()
