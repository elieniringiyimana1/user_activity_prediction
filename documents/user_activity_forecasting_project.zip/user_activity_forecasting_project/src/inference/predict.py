"""Inference pipeline."""

import logging
import os
import uuid
import numpy as np
import pandas as pd
import shap
from datetime import datetime, timedelta

from snowflake.ml.feature_store import FeatureStore
from snowflake.ml.registry import Registry

from src.common.session import get_snowflake_connection
from src.common.utils import get_config, get_reference_date, get_feature_columns, get_feature_views
from src.monitoring.create_monitor import create_monitor_if_not_exists

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def build_inference_query(cfg):
    inference_date = get_reference_date(cfg) - timedelta(days=cfg["inference"]["inference_date_offset_days"])
    return f"""
SELECT up.user_id_hex, m.date_utc
FROM {cfg["tables"]["activity_source"]} m
JOIN {cfg["tables"]["user_lookup"]} up ON m.username = up.latest_username
WHERE m.date_utc = '{inference_date}'
GROUP BY up.user_id_hex, m.date_utc
"""


def main():
    cfg = get_config()
    logger.info(f"Model: {cfg['model']['registry_name']}")
    
    session = get_snowflake_connection()
    db = os.getenv("SNOWFLAKE_DATABASE")
    schema = os.getenv("SNOWFLAKE_SCHEMA")
    warehouse = os.getenv("SNOWFLAKE_WAREHOUSE")
    
    registry = Registry(session=session, database_name=db, schema_name=schema)
    fs = FeatureStore(session=session, database=db, name=cfg["feature_store"]["name"], default_warehouse=warehouse)
    
    feature_views = get_feature_views(fs, cfg)
    spine_df = session.sql(build_inference_query(cfg))
    inference_df = fs.generate_training_set(spine_df=spine_df, features=feature_views)
    
    limit = cfg["inference"].get("data_limit")
    inference_df = (inference_df.limit(limit) if limit else inference_df).to_pandas().fillna(0)
    
    feature_cols = get_feature_columns(cfg)
    id_cols = cfg["id_columns"]
    inference_df = inference_df[id_cols + feature_cols]
    logger.info(f"Inference data: {len(inference_df)} rows")
    
    mv = registry.get_model(cfg["model"]["registry_name"]).default
    model = mv.load(force=True)
    logger.info(f"Loaded: {mv.model_name} v{mv.version_name}")
    
    X = inference_df[feature_cols]
    predictions = model.predict(X)
    
    prediction_ts = datetime.now()
    batch_id = prediction_ts.strftime("%Y%m%d_%H%M%S")
    prediction_ids = [str(uuid.uuid4()) for _ in range(len(inference_df))]
    
    results = pd.DataFrame({
        'PREDICTION_ID': prediction_ids,
        'USER_ID_HEX': inference_df['USER_ID_HEX'].values,
        'DATE_UTC': inference_df['DATE_UTC'].values,
        'PREDICTION_TIMESTAMP': prediction_ts,
        'PREDICTED_ACTIVE_DAYS': predictions,
        'ACTUAL_ACTIVE_DAYS': None,
        'MODEL_NAME': mv.model_name,
        'MODEL_VERSION': mv.version_name,
        'BATCH_ID': batch_id,
    })
    
    logger.info("Generating SHAP values...")
    X_scaled = model.named_steps["preprocess"].transform(X)
    explainer = shap.TreeExplainer(model.named_steps["model"])
    shap_values = explainer.shap_values(X_scaled)
    
    n_rows = shap_values.shape[0]
    n_features = shap_values.shape[1]
    base_pred = float(np.array(explainer.expected_value).reshape(-1)[0])
    
    shap_df = pd.DataFrame({
        'PREDICTION_ID': np.repeat(np.array(prediction_ids), n_features),
        'USER_ID_HEX': np.repeat(inference_df['USER_ID_HEX'].to_numpy(), n_features),
        'DATE_UTC': np.repeat(inference_df['DATE_UTC'].to_numpy(), n_features),
        'PREDICTION_TIMESTAMP': prediction_ts,
        'MODEL_NAME': mv.model_name,
        'MODEL_VERSION': mv.version_name,
        'BATCH_ID': batch_id,
        'BASE_PREDICTION': base_pred,
        'FEATURE_NAME': np.tile(np.array(feature_cols, dtype=object), n_rows),
        'FEATURE_VALUE': X.to_numpy().ravel(),
        'SHAP_VALUE': np.asarray(shap_values).ravel(),
    })
    
    session.create_dataframe(results).write.mode("append").save_as_table(cfg["tables"]["predictions"])
    session.create_dataframe(shap_df).write.mode("append").save_as_table(cfg["tables"]["predictions_shap"])
    logger.info(f"Saved to {cfg['tables']['predictions']}")
    
    create_monitor_if_not_exists(session, cfg, mv.version_name, warehouse)
    
    logger.info("Inference complete")


if __name__ == '__main__':
    main()
