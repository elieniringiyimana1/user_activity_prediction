"""Create model monitor."""

import logging
import os
from snowflake.ml.registry import Registry
from src.common.session import get_snowflake_connection
from src.common.utils import get_config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def create_monitor_if_not_exists(session, cfg, version, warehouse):
    """Create a model monitor for the specified version if it doesn't exist."""
    monitor_name = f"USER_ACTIVITY_MONITOR_{version}"
    logger.info(f"Checking monitor for version {version}...")
    
    try:
        monitors = session.sql(f"SHOW MODEL MONITORS LIKE '{monitor_name}'").collect()
        if len(monitors) > 0:
            logger.info(f"Monitor {monitor_name} already exists")
            return monitor_name
        logger.info(f"Monitor {monitor_name} does not exist, creating...")
    except Exception as e:
        logger.warning(f"Could not check for existing monitor: {e}")
    
    sql = f"""
CREATE MODEL MONITOR {monitor_name} WITH
    MODEL = {cfg["model"]["registry_name"]}
    VERSION = '{version}'
    FUNCTION = 'PREDICT'
    SOURCE = {cfg["tables"]["predictions"]}
    WAREHOUSE = {warehouse}
    REFRESH_INTERVAL = '{cfg["monitoring"]["refresh_interval"]}'
    AGGREGATION_WINDOW = '{cfg["monitoring"]["aggregation_window"]}'
    TIMESTAMP_COLUMN = PREDICTION_TIMESTAMP
    PREDICTION_SCORE_COLUMNS = ('PREDICTED_ACTIVE_DAYS')
    ACTUAL_SCORE_COLUMNS = ('ACTUAL_ACTIVE_DAYS')
"""
    
    session.sql(sql).collect()
    logger.info(f"Created monitor: {monitor_name}")
    return monitor_name


def main():
    """Standalone execution - creates monitor for current default version."""
    cfg = get_config()
    session = get_snowflake_connection()
    
    db = os.getenv("SNOWFLAKE_DATABASE")
    schema = os.getenv("SNOWFLAKE_SCHEMA")
    warehouse = os.getenv("SNOWFLAKE_WAREHOUSE")
    
    registry = Registry(session=session, database_name=db, schema_name=schema)
    
    model = registry.get_model(cfg["model"]["registry_name"])
    version = model.default.version_name
    
    create_monitor_if_not_exists(session, cfg, version, warehouse)


if __name__ == '__main__':
    main()
