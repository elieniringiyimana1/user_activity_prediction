"""Backfill actual values for monitoring."""

import logging
from datetime import timedelta
from src.common.session import get_snowflake_connection
from src.common.utils import get_config, get_reference_date

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def main():
    cfg = get_config()
    session = get_snowflake_connection()
    
    cutoff = get_reference_date(cfg) - timedelta(days=cfg["monitoring"]["backfill_lag_days"])
    horizon = cfg["training"]["prediction_horizon_days"]
    
    sql = f"""
UPDATE {cfg["tables"]["predictions"]} p
SET ACTUAL_ACTIVE_DAYS = (
    WITH activity AS (
        SELECT up.user_id_hex, m.date_utc, SUM(m.time_in_app_mins_per_day) AS mins
        FROM {cfg["tables"]["activity_source"]} m
        JOIN {cfg["tables"]["user_lookup"]} up ON m.username = up.latest_username
        WHERE m.date_utc > p.DATE_UTC AND m.date_utc <= DATEADD('day', {horizon}, p.DATE_UTC)
        GROUP BY up.user_id_hex, m.date_utc
    )
    SELECT COALESCE(SUM(IFF(mins > 1, 1, 0)), 0) FROM activity WHERE user_id_hex = p.USER_ID_HEX
)
WHERE p.ACTUAL_ACTIVE_DAYS IS NULL AND p.DATE_UTC < '{cutoff}'
"""
    
    result = session.sql(sql).collect()
    logger.info(f"Backfill complete: {result}")


if __name__ == '__main__':
    main()
